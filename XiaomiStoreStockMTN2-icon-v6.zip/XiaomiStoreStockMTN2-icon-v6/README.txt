VERSION 6

This version uses the supplied orange Mi icon image directly as both android:icon and android:roundIcon.

Upload/replace these files in the GitHub repository, then let Actions run.
The APK artifact will be named XiaomiStoreStockMTN2-v6.
